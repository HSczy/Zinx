package main

import (
	"fmt"
	"net"
	"time"
)

// 模拟客户端
func main() {
	fmt.Println("Client start...")
	time.Sleep(1 * time.Second)
	// 1. 直接链接远程服务器，得到一个conn链接
	conn, err := net.Dial("tcp", "127.0.0.1:8999")
	if err != nil {
		fmt.Println("Client start err,exit!")
		return
	}
	for {
		// 2. 链接调用Write 写数据
		_, err := conn.Write([]byte("hello zinx v0.1"))

	}
}
