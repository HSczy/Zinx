package main

import "fmt"

// 模拟客户端
func main() {
	fmt.Println("Client start...")
	// 1. 直接链接远程服务器，得到一个conn链接

	// 2. 链接调用Write 写数据
}
