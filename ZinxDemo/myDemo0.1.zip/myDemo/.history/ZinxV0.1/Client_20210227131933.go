package main

// 模拟客户端
func main() {

}
