package main

func main() {
	s := zent.NewServer("[zinx V0.1]")
	s.Serve()
}
